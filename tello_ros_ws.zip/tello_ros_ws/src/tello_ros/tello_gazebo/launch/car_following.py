

import cv2
import numpy 
import rclpy
from rclpy.node import Node 
from cv_bridge import CvBridge 
from sensor_msgs.msg import Image 
from geometry_msgs.msg import Twist

class line_detection_and_following(Node):
    def __init__(self):
        super().__init__('Lane_follower')
        self.subscriber = self.create_subscription(Image,'/drone1/image_raw',self.process_data,10)
        self.bridge = CvBridge() # konwersja na open CV
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 40)
        timer_period = 0.2;self.timer = self.create_timer(timer_period, self.send_cmd_vel)
        self.velocity=Twist()
        self.error=0;
        self.action=""

    ## Publiszer    
    def send_cmd_vel(self):
        ## stała predkosc
        self.velocity.linear.x=0.5
        if(self.error > 0):## sterowanie w lewo
            self.velocity.angular.z=0.15
            self.action="Go Left"
        else :## sterowanie w prawo
            self.velocity.angular.z=-0.15
            self.action="Go Right"

       
        self.publisher.publish(self.velocity)


    ## Subskryber
    def process_data(self, data): 
        frame = self.bridge.imgmsg_to_cv2(data) 
           ##### Segmentacja
        
        light_line = numpy.array([ 100,100,100])
        dark_line = numpy.array([200,200,200])
        mask = cv2.inRange(image, light_line,dark_line)
            
        ## 
        canny= cv2.Canny(mask,40,10)
        ## 
        r1=150;c1=0
        img = canny[r1:r1+240,c1:c1+640]

        ##### środek linii
 
        edge=[]
        for i in range (639):
            if(img[160,i]==255):
                edge.append(i)
        print(edge)


        if(len(edge)==4):
            edge[0]=edge[0]
            edge[1]=edge[2]
        ## 
        
        if(len(edge)==3):
            for i in range(len(edge)):
                if(edge[1]-edge[0] > 5): ## 
                    edge[0]=edge[0]
                    edge[1]=edge[1]
                else:#[193, 194, 507 ]
                    edge[0]=edge[0]
                    edge[1]=edge[2]
        ## 
        if(len(edge) < 2):
            edge=[240,440]
        
        ## Apllying a white pixel to final line mid point found
        mid_area=(edge[1]-edge[0])
        mid_point= +edge[0] + (mid_area/2)
        img[160,int(mid_point)]=255

       
            ##### punkt środkowy
        frame_mid = 639/2
            ##### sterowanie autem
        
        self.error=frame_mid-mid_point 

        
        img[160,int(frame_mid)]=255
        img[159,int(frame_mid)]=255
        img[161,int(frame_mid)]=255
       
        f_image = cv2.putText(img, self.action, (100,100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,), 2, cv2.LINE_AA)




        cv2.imshow('output image',f_image)
        cv2.waitKey(1)
        

    cv2.waitKey(0)
    cv2.destroyAllWindows()


def main(args=None):
  rclpy.init(args=args)
  image_subscriber = line_detection_and_following()
  rclpy.spin(image_subscriber)
  rclpy.shutdown()
  
if __name__ == '__main__':
  main()
