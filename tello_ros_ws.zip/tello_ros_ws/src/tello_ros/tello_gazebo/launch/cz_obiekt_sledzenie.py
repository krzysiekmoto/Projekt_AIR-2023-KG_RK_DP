

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from geometry_msgs.msg import Twist

# połączenie z topiciem z obrazem z kamery drona
image_sub = rospy.Subscriber("drone1/image_raw", Image, image_callback)

# połączenie z topiciem do komunikacji z dronem
move_pub = rospy.Publisher("drone1/cmd_vel", Twist, queue_size=1)

# obiekt do konwersji obrazu z ROS na OpenCV
bridge = CvBridge()

self.min__object_size = 500 #minimalny rozmiar w pikselach

# pętla główna
while not rospy.is_shutdown():
    # pobranie obrazu z kamery drona
    frame = bridge.imgmsg_to_cv2(data, "bgr8")
# przetworzenie obrazu na przestrzeń HSV
hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

# wykrycie czerwonego obiektu
lower_red = np.array([0, 120, 70])
upper_red = np.array([10, 255, 255])
mask = cv2.inRange(hsv, lower_red, upper_red)
res = cv2.bitwise_and(frame, frame, mask=mask)

# określenie położenia czerwonego obiektu
contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
for cnt in contours:
    (x, y), radius = cv2.minEnclosingCircle(cnt)
    center = (int(x), int(y))
    radius = int(radius)
        #if radius > 10:
if radius > self.min_object_size:
        cv2.circle(frame, center, radius, (0, 255, 0), 2)
	#może if x > 1 and x < width and y >1 and y< height: ??????????????



        # wysłanie komendy do drona, aby podążał za obiektem
        move_msg = Twist()
        move_msg.linear.x = x
        move_msg.linear.y = y
        move_msg.linear.z = 1
        move_msg.angular.x = 1
        move_msg.angular.y = 1
        move_msg.angular.z = 1
        move_pub.publish(move_msg)  
else:
#obiekt poza polem widzenia
print("obiekt poza polem widzenia kamery")

cv2.imshow("Red object detection", res)
cv2.waitKey(0)
cv2.destroyAllWindows()
