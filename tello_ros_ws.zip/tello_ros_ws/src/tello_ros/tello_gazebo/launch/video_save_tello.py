
import rclpy 
import cv2 
from rclpy.node import Node 
from cv_bridge import CvBridge 
from sensor_msgs.msg import Image 


class Video_get(Node):
  def __init__(self):
    super().__init__('video_subscriber')
    ## subskryber
    self.subscriber = self.create_subscription(Image,'/drone1/image_raw',self.process_data,10)
    ## zapis klatek do pliku video
    self.out = cv2.VideoWriter('/home/output_tello.avi',cv2.VideoWriter_fourcc('M','J','P','G'), 10, (640,480))
    self.bridge = CvBridge() 
 
  ## Subskryber 
  def process_data(self, data): 
    # konwersja
    frame = self.bridge.imgmsg_to_cv2(data) 
    # zapis klatek do pliku video
    self.out.write(frame)
    # wyswietlanie
    cv2.imshow("output", frame) 
    # waitkey
    cv2.waitKey(1) 
  

  
def main(args=None):
  rclpy.init(args=args)
  image_subscriber = Video_get()
  rclpy.spin(image_subscriber)
  rclpy.shutdown()
  
if __name__ == '__main__':
  main()
