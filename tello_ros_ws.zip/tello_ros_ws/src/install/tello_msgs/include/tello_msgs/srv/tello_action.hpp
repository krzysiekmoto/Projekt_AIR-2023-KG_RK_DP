// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TELLO_MSGS__SRV__TELLO_ACTION_HPP_
#define TELLO_MSGS__SRV__TELLO_ACTION_HPP_

#include "tello_msgs/srv/tello_action__struct.hpp"
#include "tello_msgs/srv/tello_action__traits.hpp"

#endif  // TELLO_MSGS__SRV__TELLO_ACTION_HPP_
