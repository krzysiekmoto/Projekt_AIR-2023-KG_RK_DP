// generated from rosidl_generator_c/resource/idl.h.em
// with input from tello_msgs:msg/TelloResponse.idl
// generated code does not contain a copyright notice

#ifndef TELLO_MSGS__MSG__TELLO_RESPONSE_H_
#define TELLO_MSGS__MSG__TELLO_RESPONSE_H_

#include "tello_msgs/msg/tello_response__struct.h"
#include "tello_msgs/msg/tello_response__functions.h"
#include "tello_msgs/msg/tello_response__type_support.h"

#endif  // TELLO_MSGS__MSG__TELLO_RESPONSE_H_
