// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TELLO_MSGS__MSG__FLIGHT_DATA_HPP_
#define TELLO_MSGS__MSG__FLIGHT_DATA_HPP_

#include "tello_msgs/msg/flight_data__struct.hpp"
#include "tello_msgs/msg/flight_data__traits.hpp"

#endif  // TELLO_MSGS__MSG__FLIGHT_DATA_HPP_
