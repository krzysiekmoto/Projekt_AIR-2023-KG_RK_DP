import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from geometry_msgs.msg import Twist
from tello_msgs.srv import TelloAction

class MyTello(Node):
        def image_callback(self,msg):

                # pętla główna
                
                        # pobranie obrazu z kamery drona
                frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")# może być bez data do spr
                # przetworzenie obrazu na przestrzeń HSV
                hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

                # wykrycie czerwonego obiektu
                lower_red = np.array([0, 120, 70])
                upper_red = np.array([10, 255, 255])
                mask = cv2.inRange(hsv, lower_red, upper_red)
                res = cv2.bitwise_and(frame, frame, mask=mask)

                #move_msg = Twist()
                #move_msg.linear.x = 0.2
                #move_msg.linear.y = 0.0
                #move_msg.linear.z = 0.0
                #move_msg.angular.x = 0.0
                #move_msg.angular.y = 0.0
                #move_msg.angular.z = 0.0
                #self.move_pub.publish(move_msg)  

                # określenie położenia czerwonego obiektu
                contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                for cnt in contours:
                        (x, y), radius = cv2.minEnclosingCircle(cnt)
                        center = (int(x), int(y))
                        radius = int(radius)
                                #if radius > 10:
                        if radius > self.min_object_size:
                                cv2.circle(frame, center, radius, (0, 255, 0), 2)

                                # wysłanie komendy do drona, aby podążał za obiektem
                                move_msg = Twist()
                                move_msg.linear.x = x
                                move_msg.linear.y = y
                                move_msg.linear.z = 0
                                move_msg.angular.x = 0
                                move_msg.angular.y = 0
                                move_msg.angular.z = 0
                                self.move_pub.publish(move_msg)  
                        else:
                        #obiekt poza polem widzenia
                                print("obiekt poza polem widzenia kamery")
                cv2.imshow("Red object detection", res)
                cv2.waitKey(1)

        def __init__(self):
                super().__init__('tello') 

                # połączenie z topiciem do komunikacji z dronem
                self.move_pub = self.create_publisher( Twist, "drone1/cmd_vel", 10)

                self.tello_service_client = self.create_client(TelloAction, '/drone1/tello_action')
                self.service_request = TelloAction.Request()
                # obiekt do konwersji obrazu z ROS na OpenCV
                self.bridge = CvBridge()

                self.min_object_size = 500 #minimalny rozmiar w pikselach
                while not self.tello_service_client.wait_for_service(timeout_sec=1.0):
                        self.get_logger().info("Oczekuje na dostępność usługi Tello...")
                self.service_request.cmd='takeoff'
                self.tello_service_client.call_async(self.service_request)

                # połączenie z topiciem z obrazem z kamery drona
                self.image_sub = self.create_subscription(Image,"drone1/image_raw", self.image_callback, 10)

def main(args=None):
        rclpy.init()
        hwn=MyTello()
        rclpy.spin(hwn)
        hwn.destroy_node()
        cv2.destroyAllWindows()
        rclpy.shutdown()



